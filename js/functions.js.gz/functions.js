// JavaScript Document

$(document).ready(function() {
   var panelHeight;
   var hash = window.location.hash;
   $("#less").hide();
   if(hash == "#letMedo"){
	   $("#content").height(1680);
	   $("#more").hide();
	   $("#less").show();
   } else {
	   $("#content").show().height(180);
   }	    
   $("#more").click(function() {
      panelHeight = $("#content").height();
	   if(panelHeight >= 180 && panelHeight < 1180){
        $("#content").animate({height: '+=500px'},750,function(){$("#intro p").fadeOut(),$("#more-arrow").fadeOut()});
	    $("#less").fadeIn();
	   } else {
	    $("#content").animate({height: '+=500px'},750,function(){$("#more").fadeOut()});
       }
   });	
   $("#less").click(function() {
      panelHeight = $("#content").height();
	   if(panelHeight <= 1680 && panelHeight > 680){
        $("#content").animate({height: '-=500px'},750);
	    $("#more").fadeIn();
	   } else {
	    $("#content").animate({height: '-=500px'},750,function(){$("#less").fadeOut(),$("#intro p").fadeIn(),$("#more-arrow").fadeIn()});
       }
    });	
	$('#coda-slider-1').codaSlider({
       dynamicArrows: false,
       dynamicTabs: false,
	   autoHeight: false
    });
});